// Entry point: dispatch draft and gameplay; a failed turn is swallowed and still yields.
#include "brain.h"
#include "draft.h"
#include <cstdio>

namespace
{
// v9 watchdog (P.watchdog): a turn that keeps throwing (an unexpected map or SDK state) used to idle the body for the rest of the
// game. After P.watchdog consecutive failures this plays a minimal, defensive turn instead: bank if next to an altar, else hit a
// visible camp in range, else walk home. Every call is guarded; the next normal turn resets the counter.
void fallback_turn()
{
	auto& me = bc::self();
	if (!me.is_alive())
		return;
	const vec2 p = me.position();
	if (me.gem_count() > 0)
		for (const auto a : bc::map::altars().positions())
			if (cheb(a, p) <= 1)
			{
				me.submit_gems(a);
				return;
			}
	if (me.can_attack())
		for (const auto& c : bc::vision::camps())
			if (c.is_alive() && cheb(c.position(), p) <= me.attack_range())
			{
				me.attack(c);
				return;
			}
	if (me.can_move())
	{
		const auto home = bc::map::spawn_region(team::ally).positions();
		if (!home.empty())
			me.move_towards(home.front());
	}
}
} // namespace

int main()
{
	int fails = 0;
	while (true)
	{
		try
		{
			if (bc::is_draft())
				play_draft();
			else
				brain().turn();
			fails = 0;
		}
		catch (...)
		{
			++fails;
			if (P.watchdog > 0 && fails >= P.watchdog && !bc::is_draft())
			{
				try
				{
					fallback_turn();
				}
				catch (...)
				{
				}
			}
		}
#ifdef LEGEND_TRACE
		debug_block({
			const auto left = bc::fuel_remaining();
			if (!bc::is_draft() && left < 15000)
				std::printf("FUEL low r=%u left=%llu\n", bc::round_number(), static_cast<unsigned long long>(left));
		});
#endif
		bc::end_turn();
	}
}
